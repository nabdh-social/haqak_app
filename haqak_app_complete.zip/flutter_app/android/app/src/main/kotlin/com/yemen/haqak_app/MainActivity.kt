package com.yemen.haqak_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
