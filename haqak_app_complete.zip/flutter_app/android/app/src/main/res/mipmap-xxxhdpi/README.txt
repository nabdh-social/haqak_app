ضع هنا أيقونات التطبيق:
- ic_launcher.png (192x192)
- ic_launcher_round.png (192x192)

يمكنك إنشاء أيقونات بسهولة عبر:
https://romannurik.github.io/AndroidAssetStudio/icons-launcher.html
